package com.example.pjandroid;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toolbar;

import java.util.ArrayList;

import petrov.kristiyan.colorpicker.ColorPicker;

public class page_option extends AppCompatActivity {

    private Button Bcolor;
    private Button Bplanning;
    private Button Badresse;
    private Button Bsonnerie;
    private Button Bvalidate;
    private Button Bsuivant4;
    private Button Burl;
    private Button Bsuivant;
    private Button button1;

    private Toolbar toolbar;

    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String TEXT = "text";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_option);

        LinearLayout lay = findViewById(R.id.base);

        toolbar = findViewById(R.id.toolbar);

        Bcolor = (Button) findViewById(R.id.button_ColorPicker);
        Badresse = (Button) findViewById(R.id.button_setAdresse);
        Bplanning = (Button) findViewById(R.id.button_setPlanning);
        Bsonnerie = (Button) findViewById(R.id.button_setSonnerie);
        Bvalidate = (Button) findViewById(R.id.button_validate);

        Bsuivant4 = (Button) findViewById(R.id.btnSuivant4);
        Burl = (Button) findViewById(R.id.urlButton);
        Bsuivant = (Button) findViewById(R.id.btnSuivant);
        button1 = (Button) findViewById(R.id.button1);

        Bvalidate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                savedata();
            }

        });
        Bcolor.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                opencolorpicker();
            }
        });
    }

    private void savedata() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();


    }

    public void opencolorpicker(){
        final ColorPicker colorPicker = new ColorPicker(this);
        ArrayList<String> colors = new ArrayList<>();
        colors.add("#ffffff");
        colors.add("#e0795d");
        colors.add("#f3ce00");
        colors.add("#4ebdad");
        colors.add("#ff2500");
        colors.add("#6c3e2c");
        colors.add("#efce79");
        colors.add("#e0795d");
        colors.add("#3d1159");
        colors.add("#fedb90");

        final ArrayList<Button> buttonList = new ArrayList<>();
        buttonList.add(Bcolor);
        buttonList.add(Badresse);
        buttonList.add(Bplanning);
        buttonList.add(Bsonnerie);
        buttonList.add(Bvalidate);

        buttonList.add(Bsuivant4);
        buttonList.add(Burl);
        buttonList.add(Bsuivant);
        buttonList.add(button1);

        colorPicker.setColors(colors).setColumns(5).setRoundColorButton(true)
                .setOnChooseColorListener(new ColorPicker.OnChooseColorListener() {

                    @Override
                    public void onChooseColor(int position,int color) {
                        for (Button btn : buttonList) {
                            btn.setBackgroundColor(color);
                        }
                    }

                    @Override
                    public void onCancel(){


                    }
                }).show();

    }
}
