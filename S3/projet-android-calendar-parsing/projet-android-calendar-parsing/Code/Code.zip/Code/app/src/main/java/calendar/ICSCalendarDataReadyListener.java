package calendar;

public interface ICSCalendarDataReadyListener {
    void dataReady();
}
