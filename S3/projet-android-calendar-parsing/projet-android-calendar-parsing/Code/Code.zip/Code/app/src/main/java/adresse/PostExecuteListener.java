package adresse;

public interface PostExecuteListener {

    public void onPostExecute(Boolean b);
}
