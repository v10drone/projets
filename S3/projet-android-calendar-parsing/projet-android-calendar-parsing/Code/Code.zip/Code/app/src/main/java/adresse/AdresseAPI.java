package adresse;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Toast;

import com.example.pjandroid.Config3_4;
import com.example.pjandroid.R;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//Android n'autorise pas les tâches en arrière-plan dans le main
//Car cela signifierai que l'appli va froze et donc NO GOOD !
//Donc faut faire une autre classe qui va fetch les datas
//= CREER UN AUTRE THREAD qui va s'en occuper sans froze l'app
public class AdresseAPI extends AsyncTask<Void, Void, Boolean> {
    private AutoCompleteTextView adresse;
    private EditText cp;
    private Boolean bool;
    private Activity activity;
    private String type;
    private PostExecuteListener listener;

    private static List<String> ADRESSE_SUGGESTION = new ArrayList<String>(Arrays.asList("TOTO","TATI"));

    public AdresseAPI(AutoCompleteTextView a, EditText c, Activity act, String t, PostExecuteListener l) {
        super();
        adresse = a;
        cp = c;
        bool = false;
        activity = act;
        type = t;
        listener = l;

        Log.d("DEBUG","EVVVVENNNTTT");
        //On définit levent qu'on on tape du texte
//        adresse.setOnKeyListener(new View.OnKeyListener() {
//            @Override
//            public boolean onKey(View v, int keyCode, KeyEvent event) {
//                return false;
////                //Si la taille de l'input est plus petit que 3 on fait rien
////                if (adresse.getText().toString().length() < 3) {
////                    return true;
////                }
////
////                doInBackground();
////                return true;
//            }
//        });



        //Avec ses ligne on synchronise la liste Adresse_suggestion et l'input
//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(act.getApplicationContext(), android.R.layout.simple_list_item_1, (String[]) ADRESSE_SUGGESTION.toArray());
//        adresse.setAdapter(adapter);


    }

    public boolean getBool() {
        return bool;
    }

    protected Boolean doInBackground(Void... Voids) {
        String a = adresse.getText().toString().replaceAll(" ", "+");
        String v = cp.getText().toString();
        String lien = "https://api-adresse.data.gouv.fr/search/?q=" + a + "&postcode=" + v;
        Log.d("DEBUG", lien);
        try {
            URL url = new URL(lien);
            HttpURLConnection co = (HttpURLConnection) url.openConnection(); //Connexion au site
            InputStream in = co.getInputStream();
            BufferedReader out = new BufferedReader(new InputStreamReader(in));//to read data from this input stream
            String line = "";
            String data = "";
            while (line != null) {
                line = out.readLine();
                data = data + line; //contient tte les data du JSON
            }
            JSONObject ja = new JSONObject(data);
            JSONArray features = (JSONArray) ja.get("features");
            Log.d("DEBUG", ja.toString());
            Log.d("DEBUG", features.length() + "");


            if (features.length() == 1) {
                    bool = true;
            }
//            ADRESSE_SUGGESTION.clear();
//            for (int i = 0; i < features.length(); i++) {
//                JSONObject adresseObject = features.getJSONObject(i);
//                ADRESSE_SUGGESTION.add((String) ( (JSONObject) adresseObject.get("properties")).get("label"));
//            }


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }


    @Override
    protected void onPostExecute(Boolean b) {
        super.onPostExecute(b);
        listener.onPostExecute(bool);
    }


}