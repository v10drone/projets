package com.example.pjandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import adresse.AdresseAPI;
import adresse.PostExecuteListener;

public class Config1_4 extends AppCompatActivity {

    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.config1_4);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("HelloMorning !");
        toolbar.setTitleMargin(210,10,50,10);
        toolbar.setLogo(R.drawable.ic_alarm_black_24dp);

        final AutoCompleteTextView adresseD = (AutoCompleteTextView) findViewById(R.id.adresseDomicile);
        final EditText villeD = (EditText) findViewById(R.id.villeDomicile);
        final EditText adresseT = (EditText) findViewById(R.id.adresseTravail);
        final EditText villeT = (EditText) findViewById(R.id.villeTravail);
        EditText pseudo = (EditText) findViewById(R.id.pseudo);


        Button btnSuivant = (Button) findViewById(R.id.btnSuivant4);
        btnSuivant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AdresseAPI a = new AdresseAPI(adresseD, villeD, Config1_4.this, "Domicile", new PostExecuteListener() {
                    @Override
                    public void onPostExecute(Boolean b) {
                        if (b) {
                            //Stockage dans sharedPref à faire--------------------------------------HERE !
                            Intent intent = new Intent(getApplicationContext(), Config3_4.class);
                            startActivity(intent);
                        } else {
                            String pb = "Veuillez vérifier l'adresse suivante : '" + adresseD.getText().toString() + "'" + " CP : " + villeD.getText().toString();
                            Toast.makeText(Config1_4.this, pb, Toast.LENGTH_LONG).show();
                        }
                    }
                });

                a.execute();
            }
        });
    }

    public void Go(android.view.View v){
        Intent intent = new Intent(this, page_option.class);
        startActivity(intent);
    }

    public void saveData() {

    }
}
